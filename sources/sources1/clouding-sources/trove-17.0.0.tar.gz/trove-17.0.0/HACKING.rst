Trove Library Specific Commandments
-------------------------------------

- [T103] Exception messages should be translated
- [T105] Validate no LOG translations
