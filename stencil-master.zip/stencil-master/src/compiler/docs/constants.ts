export const AUTO_GENERATE_COMMENT = `<!-- Auto Generated Below -->`;
export const NOTE = `*Built with [StencilJS](https://stenciljs.com/)*`;
