===========
image_serve
===========

.. ansibleautoplugin::
   :role: roles/image_serve

