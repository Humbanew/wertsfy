.. _configuring:

===================
Configuration Guide
===================

This section provides a list of all possible options for each
configuration file.  Refer to :ref:`basic-configuration` for a
detailed guide in getting started with various option settings.

Zaqar uses the following configuration files for its various services.

.. toctree::
   :glob:
   :maxdepth: 1

   *

