=================================
Module - ceph_pools_pg_protection
=================================


This module provides for the following ansible plugin:

    * ceph_pools_pg_protection


.. ansibleautoplugin::
   :module: library/ceph_pools_pg_protection.py
   :documentation: true
   :examples: true

