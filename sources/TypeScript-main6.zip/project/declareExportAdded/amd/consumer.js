///<reference path="ref.d.ts" />
// in the generated code a 'this' is added before this call
M1.f1();
