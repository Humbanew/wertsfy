# RobloxApi-Definitions-Emmy  
Mainly for a comment but use as you plea  
This is not complete! and may or may not get updates  

to get `enumList.txt` run the code that you can find in `api/roblox/Enum.lua`  
in roblox studio's console window  
then copy the output to `enumList.txt`  
then finally you can run the python script for it
