======================================
Mistral Configuration and Policy Guide
======================================

.. toctree::
   :maxdepth: 2

   ../configuration/config-guide.rst
   ../configuration/policy-guide.rst
   ../configuration/samples/index.rst
