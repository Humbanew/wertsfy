define(["require", "exports", "m5"], function (require, exports, m5) {
    "use strict";
    exports.__esModule = true;
    exports.n = exports.x = exports.d = void 0;
    exports.d = m5.foo2();
    exports.x = m5.foo2;
    function n() {
        return m5.foo2();
    }
    exports.n = n;
});
