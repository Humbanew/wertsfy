Element to install an Trove guest agent.

Note: this requires a system base image modified to include Trove source code
repositories
