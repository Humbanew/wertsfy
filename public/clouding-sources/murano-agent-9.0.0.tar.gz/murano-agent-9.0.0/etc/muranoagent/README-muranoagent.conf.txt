To generate the sample muranoagent.conf file, run the following
command from the top level of the murano-agent directory:

tox -egenconfig
