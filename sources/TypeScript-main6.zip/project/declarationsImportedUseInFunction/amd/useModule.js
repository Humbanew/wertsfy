define(["require", "exports", "fncOnly_m4"], function (require, exports, fncOnly_m4) {
    "use strict";
    exports.__esModule = true;
    exports.useFncOnly_m4_f4 = void 0;
    exports.useFncOnly_m4_f4 = fncOnly_m4.foo();
});
