=============================
Sample networking-bgpvpn.conf
=============================

This sample configuration can also be viewed in `the raw format
<../../_static/config-samples/networking-bgpvpn.conf.sample>`_.

.. literalinclude::
   ../../_static/config-samples/networking-bgpvpn.conf.sample
