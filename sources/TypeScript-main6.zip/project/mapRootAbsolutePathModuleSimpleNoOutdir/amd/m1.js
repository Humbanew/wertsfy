define(["require", "exports"], function (require, exports) {
    "use strict";
    exports.__esModule = true;
    exports.m1_f1 = exports.m1_instance1 = exports.m1_c1 = exports.m1_a1 = void 0;
    exports.m1_a1 = 10;
    var m1_c1 = /** @class */ (function () {
        function m1_c1() {
        }
        return m1_c1;
    }());
    exports.m1_c1 = m1_c1;
    exports.m1_instance1 = new m1_c1();
    function m1_f1() {
        return exports.m1_instance1;
    }
    exports.m1_f1 = m1_f1;
});
//# sourceMappingURL=/tests/cases/projects/outputdir_module_simple/mapFiles/m1.js.map