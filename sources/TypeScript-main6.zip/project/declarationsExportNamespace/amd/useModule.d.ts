declare module moduleB {
    interface IUseModuleA {
        a: moduleA.A;
    }
}
