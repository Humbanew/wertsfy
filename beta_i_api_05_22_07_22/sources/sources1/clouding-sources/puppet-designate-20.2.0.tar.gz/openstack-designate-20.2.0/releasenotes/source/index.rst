==========================================
Welcome to puppet-designate Release Notes!
==========================================

Contents
========

.. toctree::
   :maxdepth: 2

   unreleased
   xena
   wallaby
   victoria
   ussuri
   train
   stein
   rocky
   queens
   pike
   ocata
   newton
   mitaka


Indices and tables
==================

* :ref:`genindex`
* :ref:`search`
