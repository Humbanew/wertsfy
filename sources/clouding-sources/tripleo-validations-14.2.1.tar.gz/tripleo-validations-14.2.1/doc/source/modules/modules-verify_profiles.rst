========================
Module - verify_profiles
========================


This module provides for the following ansible plugin:

    * verify_profiles


.. ansibleautoplugin::
   :module: library/verify_profiles.py
   :documentation: true
   :examples: true

