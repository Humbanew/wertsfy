Sets up a redis server install in the image.
