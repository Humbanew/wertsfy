.. _zaqar.conf:

----------
zaqar.conf
----------

.. show-options::
   :config-file: etc/oslo-config-generator/zaqar.conf
