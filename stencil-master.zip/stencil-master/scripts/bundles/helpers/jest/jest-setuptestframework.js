const { jestSetupTestFramework } = require('./index.js');

jestSetupTestFramework();
