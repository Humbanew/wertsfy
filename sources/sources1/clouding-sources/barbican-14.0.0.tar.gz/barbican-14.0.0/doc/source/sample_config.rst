==================================
Barbican Sample Configuration File
==================================

Use the ``barbican.conf`` file to configure most Key Manager service
options:

.. only:: html

    .. literalinclude:: _static/barbican.conf.sample
