Shared File System service resources
====================================

.. toctree::
   :maxdepth: 1

   v2/availability_zone
