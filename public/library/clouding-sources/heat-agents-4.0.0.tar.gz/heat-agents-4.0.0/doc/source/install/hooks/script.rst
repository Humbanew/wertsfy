======
script
======

A hook which invokes the provided configuration as an executable script.
Config inputs are passed in as environment variables, and output values are
read from written-out files.
