package net.minecraftforge.forge.tasks.checks

import groovy.transform.CompileStatic

@CompileStatic
enum CheckMode {
    CHECK,
    FIX
}
