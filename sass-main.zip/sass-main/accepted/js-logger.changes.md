## Draft 2

* Add a `logger` option to the new JS API.

* Add a `Logger.silent` field.

## Draft 1

* Initial draft.
