===============
project cleanup
===============

Clean resources associated with a specific project based on OpenStackSDK
implementation

Block Storage v2, v3; Compute v2; Network v2; DNS v2; Orchestrate v1


.. autoprogram-cliff:: openstack.common
   :command: project cleanup
