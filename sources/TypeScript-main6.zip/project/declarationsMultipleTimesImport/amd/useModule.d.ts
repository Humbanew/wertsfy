import m4 = require("m4");
export declare var x4: m4.d;
export declare var d4: typeof m4.d;
export declare var f4: m4.d;
export declare module m1 {
    var x2: m4.d;
    var d2: typeof m4.d;
    var f2: m4.d;
}
export declare var useMultiImport_m4_x4: m4.d;
export declare var useMultiImport_m4_d4: typeof m4.d;
export declare var useMultiImport_m4_f4: m4.d;
