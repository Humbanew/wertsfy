=================
Contributor Guide
=================

There is no topic specific to Zaqar UI now.

See `Horizon Contributor Documentation
<https://docs.openstack.org/horizon/latest/contributor/index.html>`__
for general topic on developing a dashboard on horizon.

----

.. toctree::
   :glob:
   :maxdepth: 1

   api
