====
salt
====

A hook which uses salt library to apply the provided configuration
as a state. Config inputs are passed as opts and output values are
read from the yaml returned.
