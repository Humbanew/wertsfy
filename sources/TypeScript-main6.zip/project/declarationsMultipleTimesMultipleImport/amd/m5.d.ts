import m4 = require("m4");
export declare function foo2(): m4.d;
