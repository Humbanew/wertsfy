==============
Mistral Extras
==============

.. image:: https://governance.openstack.org/tc/badges/mistral-extra.svg
    :target: https://governance.openstack.org/tc/reference/tags/index.html

.. Change things from this point on

Mistral Extra is a library which allows contributors to add optional
functionality to the mistral project, it also contains examples for which
to base new capabilities.
