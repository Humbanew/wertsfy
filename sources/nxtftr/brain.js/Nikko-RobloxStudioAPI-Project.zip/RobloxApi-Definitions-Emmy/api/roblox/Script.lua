-- Manually Created


---@class Script
local Script = {
    ---@type string
    Source=nil,
    ---@type Instance
    Parent=nil
}

---@return string
function Script:GetHash() end


script = Script
