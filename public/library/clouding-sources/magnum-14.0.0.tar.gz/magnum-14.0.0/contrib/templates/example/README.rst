========================
Example Cluster Template
========================

The purpose of this example template is to demonstrate working with cluster
templates using magnum service.
The Heat template used in this example (example.yaml) provisions a single
server instance and does not produce a usable cluster.

See `<http://docs.openstack.org/developer/magnum/dev/cluster-type-definition.html>`_ for instructions.
