===============
 CLI Reference
===============

.. toctree::
   :maxdepth: 2

   nova
