"use strict";
exports.__esModule = true;
exports.useFncOnly_m4_f4 = void 0;
var fncOnly_m4 = require("fncOnly_m4");
exports.useFncOnly_m4_f4 = fncOnly_m4.foo();
