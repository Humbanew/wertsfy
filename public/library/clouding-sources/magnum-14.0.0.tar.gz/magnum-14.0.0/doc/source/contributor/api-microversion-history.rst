.. include:: ../../../magnum/api/rest_api_version_history.rst
