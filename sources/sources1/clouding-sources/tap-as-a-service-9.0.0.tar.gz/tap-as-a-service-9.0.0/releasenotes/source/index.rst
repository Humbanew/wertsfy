.. tap-as-a-service documentation master file, created by
   sphinx-quickstart on Sun May  8 12:21:42 2016.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

Tap-as-a-service Release Notes
==============================

Contents:

.. toctree::
   :maxdepth: 2

   unreleased
   train
   stein
   queens
