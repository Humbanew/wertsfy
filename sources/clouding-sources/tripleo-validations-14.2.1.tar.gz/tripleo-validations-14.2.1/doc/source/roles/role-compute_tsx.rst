===========
compute_tsx
===========

.. literalinclude:: ../../../roles/compute_tsx/README.md

.. ansibleautoplugin::
   :role: roles/compute_tsx

