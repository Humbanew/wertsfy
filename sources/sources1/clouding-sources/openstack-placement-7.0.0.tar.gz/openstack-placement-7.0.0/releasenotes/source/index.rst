
Placement Release Notes
=======================

.. note:: The placement service was extracted from the nova service at the
          beginning of the Stein cycle. Release history prior to Stein can
          be found in the `Nova Release Notes
          <https://docs.openstack.org/releasenotes/nova/>`_.

.. toctree::
   :maxdepth: 1

   unreleased
   xena
   wallaby
   victoria
   ussuri
   train
   stein
