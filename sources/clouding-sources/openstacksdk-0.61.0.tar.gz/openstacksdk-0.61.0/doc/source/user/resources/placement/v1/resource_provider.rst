openstack.placement.v1.resource_provider
========================================

.. automodule:: openstack.placement.v1.resource_provider

The ResourceProvider Class
--------------------------

The ``ResourceProvider`` class inherits from
:class:`~openstack.resource.Resource`.

.. autoclass:: openstack.placement.v1.resource_provider.ResourceProvider
   :members:
