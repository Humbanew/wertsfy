===========================
Administrator Documentation
===========================

This chapter contains all needed information about how to install and
configure a Mistral cluster.

.. toctree::
    :maxdepth: 1

    architecture
    quickstart
    install/index
    configuration/index
    upgrade_guide
