===========================================
Mitaka Series (0.0.1 - 1.0.x) Release Notes
===========================================

.. release-notes::
   :branch: origin/stable/mitaka
