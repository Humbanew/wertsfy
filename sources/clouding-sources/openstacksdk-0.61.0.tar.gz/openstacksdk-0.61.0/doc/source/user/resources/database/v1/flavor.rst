openstack.database.v1.flavor
============================

.. automodule:: openstack.database.v1.flavor

The Flavor Class
----------------

The ``Flavor`` class inherits from :class:`~openstack.resource.Resource`.

.. autoclass:: openstack.database.v1.flavor.Flavor
   :members:
