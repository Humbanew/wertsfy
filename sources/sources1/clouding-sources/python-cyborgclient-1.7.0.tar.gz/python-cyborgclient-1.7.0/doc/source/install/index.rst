=======================================
Cyborg Python Client installation guide
=======================================

At the command line::

    $ pip install python-cyborgclient

Or, if you have virtualenvwrapper installed::

    $ mkvirtualenv python-cyborgclient
    $ pip install python-cyborgclient
