=================
Old Release Notes
=================

2.2.2
-----

* improved support for listing a large number of filtered subnets
* add --endpoint-type and OS_ENDPOINT_TYPE to shell client
* made the publicURL the default endpoint instead of adminURL
* add ability to update security group name (requires 2013.2-Havana or later)
* add flake8 and pbr support for testing and building

2.2.0
-----

* add security group commands
* add Lbaas commands
* allow options put after positional arguments
* add NVP queue and net gateway commands
* add commands for agent management extensions
* add commands for DHCP and L3 agents scheduling
* support XML request format
* support pagination options

2.0
-----

* support Neutron API 2.0
