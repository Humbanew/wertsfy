openstack.network.v2.port
=========================

.. automodule:: openstack.network.v2.port

The Port Class
--------------

The ``Port`` class inherits from :class:`~openstack.resource.Resource`.

.. autoclass:: openstack.network.v2.port.Port
   :members:
