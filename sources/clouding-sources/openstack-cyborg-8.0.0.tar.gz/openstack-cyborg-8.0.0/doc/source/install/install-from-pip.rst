=====================
Installation with pip
=====================

At the command line::

    $ pip install openstack-cyborg

Or, if you have virtualenvwrapper installed::

    $ mkvirtualenv cyborg
    $ pip install openstack-cyborg

.. include:: common.rst
