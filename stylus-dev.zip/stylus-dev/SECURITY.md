# Security Policy

## Supported Versions

Latest only

## Reporting a Vulnerability

Security issues can be reported at [Stylus Github Issues](https://github.com/stylus/stylus/issues). Since this software is provided as-is no follow up, remediation or time lines are guaranteed.