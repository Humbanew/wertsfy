==================================
Heat Dashboard configuration guide
==================================

.. toctree::
   :maxdepth: 1

   configuration
