==========================
openstack service overview
==========================
The openstack service provides...

The openstack service consists of the following components:

``zun_tempest_plugin-api`` service
  Accepts and responds to end user compute API calls...
