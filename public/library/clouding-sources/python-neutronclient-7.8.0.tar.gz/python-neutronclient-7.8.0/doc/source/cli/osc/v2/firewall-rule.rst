===================
firewall group rule
===================

A **firewall group rule** represents a collection of attributes like ports, IP
addresses which define match criteria and action (allow, or deny) that needs to
be taken on the matched data traffic.

Network v2

.. autoprogram-cliff:: openstack.neutronclient.v2
   :command: firewall group rule *
