=================================
Module - check_ironic_boot_config
=================================


This module provides for the following ansible plugin:

    * check_ironic_boot_config


.. ansibleautoplugin::
   :module: library/check_ironic_boot_config.py
   :documentation: true
   :examples: true

