cedarish element
----------------

Based on the following projects

* [Cedarish](https://github.com/progrium/cedarish)
* [Slugbuilder](https://github.com/flynn/slugbuilder)
* [Slugrunner](https://github.com/flynn/slugrunner)

builds OpenStack Image suitable for running Heroku Buildpacks.

Currently only supports Ubuntu

The scripts used here are examples of the functionality that would be performed by the solum build process (i.e. intended to be run by a system user ) and are not representitive of end-user tooling.

