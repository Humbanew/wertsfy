Using Mistral with KeyCloak Server
==================================
