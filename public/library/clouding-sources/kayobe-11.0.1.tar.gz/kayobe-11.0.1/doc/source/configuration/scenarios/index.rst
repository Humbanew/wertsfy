=======================
Configuration Scenarios
=======================

This section provides information on configuring Kayobe for different
scenarios.

.. toctree::
   :maxdepth: 2

   all-in-one/index
