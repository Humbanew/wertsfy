=======================
keystone-tempest-plugin
=======================

Tempest plugin keystone_tempest_plugin

Tempest plugin for functional testing of keystone's LDAP and federation
features. More information can be found in the `keystone developer
documentation`_.

.. _`keystone developer documentation`: https://docs.openstack.org/developer/keystone/devref/development_best_practices.html#api-scenario-tests

* Free software: Apache license
* Documentation: https://docs.openstack.org/keystone/latest/
* Source: http://opendev.org/openstack/keystone-tempest-plugin
* Bugs: http://bugs.launchpad.net/keystone_tempest_plugin
