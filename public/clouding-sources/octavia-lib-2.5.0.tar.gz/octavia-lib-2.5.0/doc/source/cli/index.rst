================================
Command line interface reference
================================

The octavia-lib library does not provide a CLI.

See the python-octaviaclient for the Octavia CLI:

    https://docs.openstack.org/python-octaviaclient/latest/
