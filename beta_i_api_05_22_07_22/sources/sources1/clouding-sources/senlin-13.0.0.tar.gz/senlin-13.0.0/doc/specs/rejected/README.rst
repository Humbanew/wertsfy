This directory holds the feature proposals that have been rejected. These
files are archived here for references.
