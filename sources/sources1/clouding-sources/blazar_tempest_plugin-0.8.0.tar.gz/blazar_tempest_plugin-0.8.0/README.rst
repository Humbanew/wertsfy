=====================
Blazar Tempest Plugin
=====================

Tempest plugin for Blazar Project

It contains the tempest plugin for the functional testing of Blazar Project.

* Free software: Apache license
* Documentation:  https://docs.openstack.org/blazar-tempest-plugin/latest/
* Source: https://opendev.org/openstack/blazar-tempest-plugin
* Bugs: https://bugs.launchpad.net/blazar
