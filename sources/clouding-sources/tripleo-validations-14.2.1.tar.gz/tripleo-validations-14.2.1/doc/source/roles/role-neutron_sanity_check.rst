====================
neutron_sanity_check
====================

.. ansibleautoplugin::
   :role: roles/neutron_sanity_check

