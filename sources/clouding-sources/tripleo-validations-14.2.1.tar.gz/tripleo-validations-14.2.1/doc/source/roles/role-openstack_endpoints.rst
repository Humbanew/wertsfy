===================
openstack_endpoints
===================

.. ansibleautoplugin::
   :role: roles/openstack_endpoints

