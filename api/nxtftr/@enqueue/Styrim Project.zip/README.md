# Styrim Project

A primeira IA criada por mim.