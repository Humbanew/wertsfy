Developer Guide
===============

.. toctree::
   :maxdepth: 2

   api_routes
   metadata_structure
   client_structure
   api_documents

