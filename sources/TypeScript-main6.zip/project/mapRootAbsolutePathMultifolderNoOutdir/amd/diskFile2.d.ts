declare var m2_a1: number;
declare class m2_c1 {
    m2_c1_p1: number;
}
declare var m2_instance1: m2_c1;
declare function m2_f1(): m2_c1;
