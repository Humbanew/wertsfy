import glo_m4 = require("glo_m4");
export declare var useGlo_m4_x4: glo_m4.d;
export declare var useGlo_m4_d4: typeof glo_m4.d;
export declare var useGlo_m4_f4: glo_m4.d;
