Maintainer
----------
OpenStack Foundation
IRC: #openstack on OFTC

Original Authors
----------------
Bryan Davidson (bryan.davidson@rackspace.com)
Kurt Griffiths (mail@kgriffs.com)
Jamie Painter (jamie.painter@rackspace.com)
Flavio Premoli (flaper87@flaper87.org)
Zhihao Yuan (lichray@gmail.com)

See also AUTHORS for a complete list of contributors.
