CLI Reference
=============

.. toctree::
   :maxdepth: 1

   zaqar-status
