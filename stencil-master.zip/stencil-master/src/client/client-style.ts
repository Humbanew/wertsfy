import type * as d from '../declarations';

export const styles: d.StyleMap = /*@__PURE__*/ new Map();
export const modeResolutionChain: d.ResolutionHandler[] = [];
