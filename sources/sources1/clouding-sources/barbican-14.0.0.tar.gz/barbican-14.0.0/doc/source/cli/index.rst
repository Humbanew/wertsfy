CLI Reference
=============

.. toctree::
   :maxdepth: 1

   barbican-status
