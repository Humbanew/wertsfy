Accelerator v2 Resources
========================

.. toctree::
   :maxdepth: 1

   v2/device
   v2/deployable
   v2/device_profile
   v2/accelerator_request

