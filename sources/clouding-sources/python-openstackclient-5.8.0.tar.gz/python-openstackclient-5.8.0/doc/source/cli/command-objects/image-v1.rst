========
image v1
========

.. autoprogram-cliff:: openstack.image.v1
   :command: image *
