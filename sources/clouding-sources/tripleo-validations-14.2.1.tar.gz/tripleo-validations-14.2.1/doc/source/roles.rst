Documented roles in TripleO-Validations
=======================================

Contents:

.. toctree::
   :glob:

   roles/*

