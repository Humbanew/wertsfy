# This module is for backward compat

from os_ken.lib.packet.ether_types import *
