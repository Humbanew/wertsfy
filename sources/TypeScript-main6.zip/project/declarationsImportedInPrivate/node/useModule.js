"use strict";
exports.__esModule = true;
exports.usePrivate_m4_m1 = void 0;
// only used privately no need to emit
var private_m4 = require("private_m4");
var usePrivate_m4_m1;
(function (usePrivate_m4_m1) {
    var x3 = private_m4.x;
    var d3 = private_m4.d;
    var f3 = private_m4.foo();
})(usePrivate_m4_m1 = exports.usePrivate_m4_m1 || (exports.usePrivate_m4_m1 = {}));
