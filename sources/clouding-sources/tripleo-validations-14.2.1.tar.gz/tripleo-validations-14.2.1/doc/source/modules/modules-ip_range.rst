=================
Module - ip_range
=================


This module provides for the following ansible plugin:

    * ip_range


.. ansibleautoplugin::
   :module: library/ip_range.py
   :documentation: true
   :examples: true

