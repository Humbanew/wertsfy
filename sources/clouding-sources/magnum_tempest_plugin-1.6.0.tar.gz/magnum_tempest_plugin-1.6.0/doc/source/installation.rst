============
Installation
============

Tempest automatically discovers installed plugins. That's why you just need
to install the Python packages that contains the Magnum Tempest plugin in
the same environment where Tempest is installed.

At the command line::

    $ git clone https://opendev.org/openstack/magnum-tempest-plugin
    $ cd magnum-tempest-plugin/
    $ pip install -e .
