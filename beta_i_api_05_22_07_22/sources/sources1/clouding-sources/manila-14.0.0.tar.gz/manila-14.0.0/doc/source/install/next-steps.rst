.. _next-steps:

==========
Next steps
==========

Your OpenStack environment now includes the Shared File Systems service.

To add more services, see the `additional documentation on installing
OpenStack services <https://docs.openstack.org/latest/install/>`_

Continue to evaluate the Shared File Systems service by creating the service
image and running the service with the correct driver mode that you chose
while configuring the share node.
