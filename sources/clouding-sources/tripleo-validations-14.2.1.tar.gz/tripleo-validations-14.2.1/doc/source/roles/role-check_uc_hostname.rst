=================
check_uc_hostname
=================

.. literalinclude:: ../../../roles/check_uc_hostname/README.md

.. ansibleautoplugin::
  :role: roles/check_uc_hostname
