===========
frr_status
===========

.. ansibleautoplugin::
   :role: roles/frr_status

