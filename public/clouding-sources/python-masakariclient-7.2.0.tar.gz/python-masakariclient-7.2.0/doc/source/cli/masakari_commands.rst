=================
Masakari commands
=================

Masakari commands are CLI interface.

.. autoprogram-cliff:: openstack.ha.v1
   :command: *
