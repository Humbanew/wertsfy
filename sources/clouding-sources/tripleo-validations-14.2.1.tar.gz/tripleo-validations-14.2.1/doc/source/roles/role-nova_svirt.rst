=================
nova_svirt
=================

.. ansibleautoplugin::
  :role: roles/nova_svirt
