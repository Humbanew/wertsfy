# flake8: noqa

# NOTE(morgan): The keystone.api._shared module is explicitly for shared code
# between the APIs that should not be duplicated. This occurs infrequently.
# For the most part adding a new file or code to anything in this module is
# incorrect. If you are unsure of what you are doing, do not add code here.

# WARNING: THIS FILE SHOULD CONTAIN NO CODE, it is explicitly ignored by
# flake8 completely.
