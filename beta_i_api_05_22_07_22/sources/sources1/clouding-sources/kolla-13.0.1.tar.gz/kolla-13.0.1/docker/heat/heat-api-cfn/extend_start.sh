#!/bin/bash

. /usr/local/bin/kolla_httpd_setup
