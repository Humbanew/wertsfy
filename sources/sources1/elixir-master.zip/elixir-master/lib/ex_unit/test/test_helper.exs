Logger.configure_backend(:console, colors: [enabled: false])
ExUnit.start()
