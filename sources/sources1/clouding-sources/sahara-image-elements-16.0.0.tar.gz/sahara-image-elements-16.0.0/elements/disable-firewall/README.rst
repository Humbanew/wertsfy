================
disable-firewall
================

This elements disables all firewalls on the image.

Recognized firewalls:

 - iptables
 - ip6tables
 - firewalld
