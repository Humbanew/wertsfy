.. _trove-conf:

---------------------------
Trove Configuration Options
---------------------------

The following is an overview of all available configuration options in Trove.
To see sample configuration file, see :ref:`trove-config-file`.

.. show-options::
   :config-file: tools/trove-config-generator.conf
