const internalDts = `/* internal dts placeholder */`;
export default internalDts;
