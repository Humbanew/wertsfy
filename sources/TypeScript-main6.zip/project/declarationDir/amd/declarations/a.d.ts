import { B } from './subfolder/b';
export declare class A {
    b: B;
}
