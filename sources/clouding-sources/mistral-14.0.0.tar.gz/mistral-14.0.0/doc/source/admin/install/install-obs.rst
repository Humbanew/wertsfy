.. _install-obs:


Install and configure for openSUSE and SUSE Linux Enterprise
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

For information on how to install and configure the Workflow service
for openSUSE and SUSE Linux Enterprise, refer to the :doc:`Installation guide
for Ubuntu <install-ubuntu>`. Note that some commands vary by distribution and
might differ from the ones described, for instance, package management.
