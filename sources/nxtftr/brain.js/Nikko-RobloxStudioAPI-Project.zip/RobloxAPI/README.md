A series of utilities for handling Roblox's JSON API data. Originally written for [PropertiesMod](https://github.com/Blupo/PropertiesMod), but I suppose it can be used for other things.

See the [wiki](https://github.com/Blupo/RobloxAPI/wiki) for technical details.
