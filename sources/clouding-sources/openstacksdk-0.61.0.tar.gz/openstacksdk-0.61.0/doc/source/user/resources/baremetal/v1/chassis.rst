openstack.baremetal.v1.chassis
==============================

.. automodule:: openstack.baremetal.v1.chassis

The Chassis Class
-----------------

The ``Chassis`` class inherits from :class:`~openstack.resource.Resource`.

.. autoclass:: openstack.baremetal.v1.chassis.Chassis
   :members:
