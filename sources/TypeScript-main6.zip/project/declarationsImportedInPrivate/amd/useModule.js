define(["require", "exports", "private_m4"], function (require, exports, private_m4) {
    "use strict";
    exports.__esModule = true;
    exports.usePrivate_m4_m1 = void 0;
    var usePrivate_m4_m1;
    (function (usePrivate_m4_m1) {
        var x3 = private_m4.x;
        var d3 = private_m4.d;
        var f3 = private_m4.foo();
    })(usePrivate_m4_m1 = exports.usePrivate_m4_m1 || (exports.usePrivate_m4_m1 = {}));
});
