-- Manually created

---@class RBXScriptSignal
local RBXScriptSignal = {}
---@return RBXScriptConnection
function RBXScriptSignal:Connect(func) end
---@return any
function RBXScriptSignal:Wait() end