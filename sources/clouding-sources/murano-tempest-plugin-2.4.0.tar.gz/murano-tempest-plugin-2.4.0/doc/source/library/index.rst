========
Usage
========

To use murano-tempest-plugin in a project::

    import murano_tempest_tests
