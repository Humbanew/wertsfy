define(["require", "exports", "m4"], function (require, exports, m4) {
    "use strict";
    exports.__esModule = true;
    exports.foo2 = void 0;
    function foo2() {
        return new m4.d();
    }
    exports.foo2 = foo2;
});
