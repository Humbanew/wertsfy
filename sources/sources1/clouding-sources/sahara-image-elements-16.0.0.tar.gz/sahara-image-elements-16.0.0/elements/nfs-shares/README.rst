==========
nfs-shares
==========

This element installs the daemon for the kernel NFS server.
