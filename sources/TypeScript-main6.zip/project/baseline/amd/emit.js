define(["require", "exports", "./decl"], function (require, exports, g) {
    "use strict";
    exports.__esModule = true;
    var p = g.point(10, 20);
});
