.. _glance-scrubber.conf:

--------------------
glance-scrubber.conf
--------------------

.. show-options::
   :config-file: etc/oslo-config-generator/glance-scrubber.conf
