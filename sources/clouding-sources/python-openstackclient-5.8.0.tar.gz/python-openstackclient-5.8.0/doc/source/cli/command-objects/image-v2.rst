========
image v2
========

.. autoprogram-cliff:: openstack.image.v2
   :command: image *
