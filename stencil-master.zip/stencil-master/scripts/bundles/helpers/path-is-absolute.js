import { isAbsolute } from 'path';

export default isAbsolute;
