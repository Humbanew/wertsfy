To generate the sample ironic.conf file, run the following command from the top
level of the repo:

    tox -egenconfig

For a pre-generated example of the latest ironic.conf, see:

    https://docs.openstack.org/ironic/latest/configuration/sample-config.html
