-- Manually Created

---@class RBXScriptConnection
local RBXScriptConnection = {
	---@type boolean
	Connected=nil
}
---@return void
function RBXScriptConnection:Disconnect() end