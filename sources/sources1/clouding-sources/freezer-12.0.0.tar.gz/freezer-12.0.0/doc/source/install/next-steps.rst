Next steps
~~~~~~~~~~

Your OpenStack environment now includes the freezer-api service.

To add additional services, see
https://docs.openstack.org/install/
