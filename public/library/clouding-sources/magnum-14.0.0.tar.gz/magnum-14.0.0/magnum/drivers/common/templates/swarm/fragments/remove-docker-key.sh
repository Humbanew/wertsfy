#!/bin/sh

echo "removing docker key"
rm -f /etc/docker/key.json
