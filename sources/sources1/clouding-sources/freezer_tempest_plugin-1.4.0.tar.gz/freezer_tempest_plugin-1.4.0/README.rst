======================
freezer-tempest-plugin
======================

Tempest plugin for the freezer project.

Tempest plugin for functional testing of freezer backup, restore and DR features.
More information can be found in the freezer developer documentation.

* Free software: Apache license
* Documentation: https://docs.openstack.org/tempest/latest/plugin-registry.html
* Source: https://opendev.org/openstack/freezer-tempest-plugin
* Bugs: https://storyboard.openstack.org/#!/project/openstack/freezer-tempest-plugin
