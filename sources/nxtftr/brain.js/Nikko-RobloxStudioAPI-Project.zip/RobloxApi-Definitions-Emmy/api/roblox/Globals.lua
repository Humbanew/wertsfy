-- Manually created

---@return number
function elapsedTime() end

---@param seconds number
function wait(seconds) end
