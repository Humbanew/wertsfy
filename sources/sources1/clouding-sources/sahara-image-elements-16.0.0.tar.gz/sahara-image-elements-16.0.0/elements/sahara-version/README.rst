==============
sahara-version
==============

This element saves the version of a few components in a file.
