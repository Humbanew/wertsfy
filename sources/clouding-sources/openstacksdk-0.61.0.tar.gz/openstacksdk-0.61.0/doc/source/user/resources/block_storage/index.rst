Block Storage Resources
=======================

.. toctree::
   :maxdepth: 1

   v2/backup
   v2/snapshot
   v2/type
   v2/volume

   v3/backup
   v3/snapshot
   v3/type
   v3/volume
