.. _barbican.conf:

-------------
barbican.conf
-------------

.. show-options::
      :config-file: etc/oslo-config-generator/barbican.conf
