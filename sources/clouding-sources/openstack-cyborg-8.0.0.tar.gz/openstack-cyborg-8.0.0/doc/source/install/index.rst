===============
Compute service
===============

.. toctree::

   common
   install-from-source
   install-from-pip
