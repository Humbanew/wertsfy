libsvg2 - SVG Parser and renderer.

Description
-----------
libsvg2 is a SVG parser and renderer written in C.
It is hosted on GitHub at https://github.com/agambier/libsvg2.git

Dependencies
------------
libsvg2 depends on libxml2 (http://www.xmlsoft.org/).

Supported OSes
--------------
libsvg2 has been compiled and tested for the following OSes but it should
be easy to port it for other OSes.
  - Linux

History
-------
Created by Alexandre Gambier <alex.gambier.dev@gmail.com>.
