export const globalScripts = /* default */ () => {
  /**/
};
