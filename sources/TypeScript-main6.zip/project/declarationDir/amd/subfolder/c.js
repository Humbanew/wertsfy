define(["require", "exports"], function (require, exports) {
    "use strict";
    exports.__esModule = true;
    exports.C = void 0;
    var C = /** @class */ (function () {
        function C() {
        }
        return C;
    }());
    exports.C = C;
});
