"use strict";
exports.__esModule = true;
var g = require("./decl");
var p = g.point(10, 20);
