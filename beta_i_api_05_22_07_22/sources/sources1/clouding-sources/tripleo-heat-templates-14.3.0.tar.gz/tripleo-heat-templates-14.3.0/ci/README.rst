=======================
TripleO CI environments
=======================

TripleO CI environments are exclusively used for Continuous Integration
purpose or for development usage.
They should not be used in production and we don't guarantee they work outside
TripleO CI.

For more informations about TripleO CI, please look:
https://github.com/openstack-infra/tripleo-ci
