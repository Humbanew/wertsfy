import fncOnly_m4 = require("fncOnly_m4");
export declare var useFncOnly_m4_f4: fncOnly_m4.d;
