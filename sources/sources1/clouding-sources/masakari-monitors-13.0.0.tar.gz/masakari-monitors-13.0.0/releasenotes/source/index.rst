Welcome to Masakarimonitor Release Notes documentation!
========================================================

Contents
========

.. toctree::
   :maxdepth: 1

   unreleased
   xena
   wallaby
   victoria
   ussuri
   train
   stein
   rocky
   queens
   pike
   ocata

