To generate the sample magnum.conf file, run the following
command from the top level of the magnum directory:

tox -egenconfig

