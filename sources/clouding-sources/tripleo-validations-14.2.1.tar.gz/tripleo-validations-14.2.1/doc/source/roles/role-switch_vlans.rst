============
switch_vlans
============

.. ansibleautoplugin::
   :role: roles/switch_vlans

