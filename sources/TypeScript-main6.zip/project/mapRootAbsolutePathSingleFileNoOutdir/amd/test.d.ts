declare var a1: number;
declare class c1 {
    p1: number;
}
declare var instance1: c1;
declare function f1(): c1;
