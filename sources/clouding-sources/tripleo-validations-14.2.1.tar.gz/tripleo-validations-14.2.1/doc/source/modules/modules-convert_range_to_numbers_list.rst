======================================
Module - convert_range_to_numbers_list
======================================


This module provides for the following ansible plugin:

    * convert_range_to_numbers_list


.. ansibleautoplugin::
   :module: library/convert_range_to_numbers_list.py
   :documentation: true
   :examples: true

