To generate the sample kuryr.conf file, run the following
command from the top level of the kuryr directory:

tox -egenconfig

The sample file will be generated at etc/kuryr.conf.sample
