import m1 = require("ref/m1");
import m2 = require("../outputdir_module_multifolder_ref/m2");
export declare var a1: number;
export declare class c1 {
    p1: number;
}
export declare var instance1: c1;
export declare function f1(): c1;
export declare var a2: typeof m1.m1_c1;
export declare var a3: typeof m2.m2_c1;
