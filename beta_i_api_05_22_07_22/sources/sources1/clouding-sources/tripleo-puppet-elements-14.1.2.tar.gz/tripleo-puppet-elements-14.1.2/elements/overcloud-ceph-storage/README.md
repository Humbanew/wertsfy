Install all packages required for the overcloud ceph storage role.
