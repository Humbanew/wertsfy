openstack.dns.v2.recordset
==========================

.. automodule:: openstack.dns.v2.recordset

The Recordset Class
-------------------

The ``DNS`` class inherits from :class:`~openstack.resource.Resource`.

.. autoclass:: openstack.dns.v2.recordset.Recordset
   :members:
