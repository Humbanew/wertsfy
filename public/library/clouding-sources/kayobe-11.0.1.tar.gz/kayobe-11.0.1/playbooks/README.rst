Zuul Ansible Playbooks
======================

This directory contains playbooks for use by Zuul. These playbooks are not used
by kayobe - see ``ansible/``.
