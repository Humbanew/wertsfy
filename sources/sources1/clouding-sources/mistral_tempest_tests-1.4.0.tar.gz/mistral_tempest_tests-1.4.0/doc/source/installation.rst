============
Installation
============

Tempest automatically discovers installed plugins. That's why you just need
to install the Python packages that contains the Mistral Tempest plugin in
the same environment where Tempest is installed.

At the command line::

    $ git clone https://opendev.org/openstack/mistral-tempest-plugin
    $ cd mistral-tempest-plugin/
    $ pip install -e .

