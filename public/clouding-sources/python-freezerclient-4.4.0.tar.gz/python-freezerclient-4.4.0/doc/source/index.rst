==========================================
Welcome to Freezer's client documentation!
==========================================

Contents
--------

.. toctree::
   :maxdepth: 2

   user/index
   reference/index
   cli/index

For Contributors
================

* If you are a new contributor to python-freezerclient please refer: :doc:`contributor/contributing`

  .. toctree::
     :hidden:

     contributor/contributing

Indices and tables
------------------

* :ref:`genindex`
* :ref:`search`


