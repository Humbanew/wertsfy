## Running Elasticsearch

```bash
docker-compose up -d
```

should now be running at http://localhost:9200
