=============
keystone.conf
=============

Use the ``keystone.conf`` file to configure most Identity service
options. This sample configuration can also be viewed in `raw
format <../../_static/keystone.conf.sample>`_.


.. literalinclude:: ../../_static/keystone.conf.sample
