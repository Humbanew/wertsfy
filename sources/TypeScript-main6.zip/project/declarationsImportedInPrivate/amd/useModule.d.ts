export declare module usePrivate_m4_m1 {
    var numberVar: number;
}
