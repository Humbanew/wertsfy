This directory contains environments that are used in tripleo-ci.  They may change from
release to release or within a release, and should not be relied upon in a production
environment.  The top-level ``environments`` directory in tripleo-heat-templates
contains the production-ready environment files.
