This directory holds the feature proposals that have been approved. Once the
features are landed, the contents should be migrated into a design document
instead of being kept here.
