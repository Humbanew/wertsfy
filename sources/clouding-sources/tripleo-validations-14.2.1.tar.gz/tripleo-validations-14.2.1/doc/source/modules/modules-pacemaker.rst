==================
Module - pacemaker
==================


This module provides for the following ansible plugin:

    * pacemaker


.. ansibleautoplugin::
   :module: library/pacemaker.py
   :documentation: true
   :examples: true

