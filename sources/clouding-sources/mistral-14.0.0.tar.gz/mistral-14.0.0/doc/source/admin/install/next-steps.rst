.. _next-steps:

Next steps
~~~~~~~~~~

Your OpenStack environment now includes the Mistral service.

To add additional services, see `OpenStack Pike Installation Tutorials and
Guides <https://docs.openstack.org/install/>`_.
