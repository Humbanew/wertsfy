"use strict";
exports.__esModule = true;
exports.n = exports.x = exports.d = void 0;
// Do not emit unused import
var m5 = require("m5");
exports.d = m5.foo2();
exports.x = m5.foo2;
function n() {
    return m5.foo2();
}
exports.n = n;
