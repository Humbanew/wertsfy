openstack.image.v2.service_info
===============================

.. automodule:: openstack.image.v2.service_info

The Store Class
----------------

The ``Store`` class inherits from :class:`~openstack.resource.Resource`.

.. autoclass:: openstack.image.v2.service_info.Store
   :members:

The Import Info Class
---------------------

The ``Import`` class inherits from :class:`~openstack.resource.Resource`.

.. autoclass:: openstack.image.v2.service_info.Import
   :members:
