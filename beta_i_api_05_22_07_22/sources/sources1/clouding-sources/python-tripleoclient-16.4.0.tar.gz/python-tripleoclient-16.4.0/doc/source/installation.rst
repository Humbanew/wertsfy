============
Installation
============

At the command line::

    $ pip install python-tripleoclient

Or, if you have virtualenvwrapper installed::

    $ mkvirtualenv python-tripleoclient
    $ pip install python-tripleoclient
