Magnum CLI Documentation
========================

In this section you will find information on Magnum’s command line
interface.

.. toctree::
   :maxdepth: 1

   magnum-status
