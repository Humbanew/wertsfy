The source repository for this project can be found at:

   https://opendev.org/openstack/python-saharaclient

Pull requests submitted through GitHub are not monitored.

To start contributing to OpenStack, follow the steps in the contribution guide
to set up and use Gerrit:

   https://docs.openstack.org/contributors/code-and-documentation/quick-start.html

Bugs should be filed on Storyboard:

   https://storyboard.openstack.org/#!/project/openstack/python-saharaclient

For more specific information about contributing to this repository, see the
python-saharaclient contributor guide:

   https://docs.openstack.org/python-saharaclient/latest/contributor/contributing.html
