realtime-kernel
===============

realtime-kernel element replaces the default kernel with the realtime
kernel. The appropriate repos must already be enabled.
