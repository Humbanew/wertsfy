"use strict";
exports.__esModule = true;
exports.foo2 = void 0;
var m4 = require("m4"); // Emit used
function foo2() {
    return new m4.d();
}
exports.foo2 = foo2;
