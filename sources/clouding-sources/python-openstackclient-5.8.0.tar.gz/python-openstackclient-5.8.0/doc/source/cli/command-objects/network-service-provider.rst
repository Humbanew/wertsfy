========================
network service provider
========================

A **network service provider** is a particular driver that implements a
networking service

Network v2

.. _network_service_provider_list:

.. autoprogram-cliff:: openstack.network.v2
   :command: network service provider list
