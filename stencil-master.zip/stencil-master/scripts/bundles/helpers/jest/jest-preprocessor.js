const { jestPreprocessor } = require('./index.js');

module.exports = jestPreprocessor;
