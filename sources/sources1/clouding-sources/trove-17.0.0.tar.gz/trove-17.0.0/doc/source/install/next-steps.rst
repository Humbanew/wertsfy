.. _trove-next-steps:

Next steps
~~~~~~~~~~

Your OpenStack environment now includes Database services.

To add more services, see the `additional OpenStack install documentation
<http://docs.openstack.org/#install-guides>`_.
