declare var m1_a1: number;
declare class m1_c1 {
    m1_c1_p1: number;
}
declare var m1_instance1: m1_c1;
declare function m1_f1(): m1_c1;
