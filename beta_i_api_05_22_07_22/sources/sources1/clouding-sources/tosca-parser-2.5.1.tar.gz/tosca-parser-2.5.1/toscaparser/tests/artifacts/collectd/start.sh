#!/bin/bash
# This script starts collectd as a service in init.d
service collectd stop
service collectd start
