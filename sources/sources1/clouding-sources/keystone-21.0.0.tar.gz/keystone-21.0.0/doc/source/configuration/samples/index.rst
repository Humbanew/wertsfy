==========================
Sample configuration files
==========================

Configuration files can alter how keystone behaves at runtime and by default
are located in ``/etc/keystone/``. Links to sample configuration files can be
found below:

.. toctree::

   keystone-conf.rst
   logging-conf.rst
   policy-yaml.rst
