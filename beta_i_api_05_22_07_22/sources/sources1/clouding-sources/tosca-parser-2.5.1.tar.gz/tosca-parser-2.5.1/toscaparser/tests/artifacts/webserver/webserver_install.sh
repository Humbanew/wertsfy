#!/bin/sh
#This script installs apache web server

apt-get update
apt-get install -y apache2