openstack.dns.v2.zone_import
============================

.. automodule:: openstack.dns.v2.zone_import

The ZoneImport Class
--------------------

The ``DNS`` class inherits from :class:`~openstack.resource.Resource`.

.. autoclass:: openstack.dns.v2.zone_import.ZoneImport
   :members:
