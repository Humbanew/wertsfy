=====================
Module - switch_vlans
=====================


This module provides for the following ansible plugin:

    * switch_vlans


.. ansibleautoplugin::
   :module: library/switch_vlans.py
   :documentation: true
   :examples: true

