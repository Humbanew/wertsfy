======================
endpoint (Identity v3)
======================

.. autoprogram-cliff:: openstack.identity.v3
   :command: endpoint add project

.. autoprogram-cliff:: openstack.identity.v3
   :command: endpoint create

.. autoprogram-cliff:: openstack.identity.v3
   :command: endpoint delete

.. autoprogram-cliff:: openstack.identity.v3
   :command: endpoint list

.. autoprogram-cliff:: openstack.identity.v3
   :command: endpoint remove project

.. autoprogram-cliff:: openstack.identity.v3
   :command: endpoint set

.. autoprogram-cliff:: openstack.identity.v3
   :command: endpoint show
