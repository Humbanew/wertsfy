# flake8: noqa
# Note(jokke): SimpleDB is only used for unittests and #noqa
# has not been supported in production since moving
# to alembic migrations.
