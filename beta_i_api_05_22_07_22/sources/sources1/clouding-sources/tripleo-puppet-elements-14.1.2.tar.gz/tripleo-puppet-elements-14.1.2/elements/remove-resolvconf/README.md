==================
remove-resolveconf
==================

Clears an existing ``/etc/resolv.conf`` from the resulting image, so that it
it will be managed via the network configuration.

