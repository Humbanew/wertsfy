==================
default_node_count
==================

.. ansibleautoplugin::
   :role: roles/default_node_count

