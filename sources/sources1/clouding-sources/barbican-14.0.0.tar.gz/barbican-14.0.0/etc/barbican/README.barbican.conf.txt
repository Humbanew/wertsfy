To generate the sample barbican.conf file, run the following
command from the top level of the barbican directory:

tox -egenconfig
