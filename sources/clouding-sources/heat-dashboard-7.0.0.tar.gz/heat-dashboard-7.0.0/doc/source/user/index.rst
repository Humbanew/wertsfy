=================================
Heat Dashboard User Documentation
=================================

.. toctree::
   :maxdepth: 2

   stacks.rst
   template_generator.rst
