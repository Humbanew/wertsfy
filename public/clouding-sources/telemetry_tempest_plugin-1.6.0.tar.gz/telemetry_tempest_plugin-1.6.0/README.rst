========================
Telemetry Tempest Plugin
========================

Tempest plugin for Telemetry Project.

It contains tempest tests for Aodh, Ceilometer, and Gnocchi Projects.

* Free software: Apache license
* Documentation: https://docs.openstack.org/ceilometer/latest/
* Source: https://opendev.org/openstack/telemetry-tempest-plugin
* Bugs: https://bugs.launchpad.net/ceilometer
