:tocdepth: 2

========================================
 Container Infrastructure Management API
========================================

.. rest_expand_all::

.. include:: versions.inc
.. include:: urls.inc
.. include:: bays.inc
.. include:: baymodels.inc
.. include:: clusters.inc
.. include:: clustertemplates.inc
.. include:: certificates.inc
.. include:: mservices.inc
.. include:: stats.inc
.. include:: quotas.inc
