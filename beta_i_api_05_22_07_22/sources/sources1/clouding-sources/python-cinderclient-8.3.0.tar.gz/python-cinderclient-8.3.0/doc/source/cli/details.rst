==================================================
Block Storage service (cinder) command-line client
==================================================

The cinder client is the command-line interface (CLI) for
the Block Storage service (cinder) API and its extensions.

For help on a specific :command:`cinder` command, enter:

.. code-block:: console

   $ cinder help COMMAND

.. cli-docs::
