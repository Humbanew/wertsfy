export declare class d {
}
export declare var x: d;
export declare function foo(): d;
