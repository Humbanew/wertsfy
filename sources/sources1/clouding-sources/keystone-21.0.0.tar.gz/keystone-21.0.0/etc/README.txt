To generate the sample keystone.conf and keystone.policy.yaml files, run the
following commands from the top level of the keystone directory:

    tox -egenconfig
    tox -egenpolicy

For a pre-generated example of the latest files, see:

    https://docs.openstack.org/keystone/latest/configuration/samples/index.html
