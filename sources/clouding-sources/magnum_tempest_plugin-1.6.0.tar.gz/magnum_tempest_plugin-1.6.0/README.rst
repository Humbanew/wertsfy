===============================
openstack Magnum Tempest Plugin
===============================

Tempest plugin for Magnum Project

It contains the tempest tests for testing Container Infrastructure Management
Service for OpenStack.

* Free software: Apache license
* Documentation: https://docs.openstack.org/magnum/latest
* Source: https://opendev.org/openstack/magnum-tempest-plugin
* Bugs: https://storyboard.openstack.org/#!/project/openstack/magnum-tempest-plugin
