#!/bin/sh


# run script
sh /vagrant/install_devstack.sh
