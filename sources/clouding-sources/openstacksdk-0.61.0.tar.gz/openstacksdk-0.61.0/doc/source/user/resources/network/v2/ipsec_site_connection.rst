openstack.network.v2.ipsec_site_connection
==========================================

.. automodule:: openstack.network.v2.ipsec_site_connection

The IPSecSiteConnection Class
-----------------------------

The ``IPSecSiteConnection`` class inherits from
:class:`~openstack.resource.Resource`.

.. autoclass:: openstack.network.v2.ipsec_site_connection.IPSecSiteConnection
   :members:
