===================================
collect_flavors_and_verify_profiles
===================================

.. ansibleautoplugin::
   :role: roles/collect_flavors_and_verify_profiles

