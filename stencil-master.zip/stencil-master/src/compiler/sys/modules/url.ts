export const URL = globalThis.URL as any;
