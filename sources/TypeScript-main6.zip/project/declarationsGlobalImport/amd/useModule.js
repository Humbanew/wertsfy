define(["require", "exports", "glo_m4"], function (require, exports, glo_m4) {
    "use strict";
    exports.__esModule = true;
    exports.useGlo_m4_f4 = exports.useGlo_m4_d4 = exports.useGlo_m4_x4 = void 0;
    exports.useGlo_m4_x4 = glo_m4.x;
    exports.useGlo_m4_d4 = glo_m4.d;
    exports.useGlo_m4_f4 = glo_m4.foo();
});
