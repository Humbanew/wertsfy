"use strict";
exports.__esModule = true;
exports.useGlo_m4_f4 = exports.useGlo_m4_d4 = exports.useGlo_m4_x4 = void 0;
var glo_m4 = require("glo_m4");
exports.useGlo_m4_x4 = glo_m4.x;
exports.useGlo_m4_d4 = glo_m4.d;
exports.useGlo_m4_f4 = glo_m4.foo();
