openstack.baremetal.v1.volume_target
=======================================

.. automodule:: openstack.baremetal.v1.volume_target

The VolumeTarget Class
-------------------------

The ``VolumeTarget`` class inherits
from :class:`~openstack.resource.Resource`.

.. autoclass:: openstack.baremetal.v1.volume_target.VolumeTarget
   :members:
