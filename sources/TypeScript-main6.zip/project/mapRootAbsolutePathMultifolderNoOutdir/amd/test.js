/// <reference path='ref/m1.ts'/>
/// <reference path='../outputdir_multifolder_ref/m2.ts'/>
var a1 = 10;
var c1 = /** @class */ (function () {
    function c1() {
    }
    return c1;
}());
var instance1 = new c1();
function f1() {
    return instance1;
}
//# sourceMappingURL=/tests/cases/projects/outputdir_multifolder/mapFiles/outputdir_multifolder/test.js.map