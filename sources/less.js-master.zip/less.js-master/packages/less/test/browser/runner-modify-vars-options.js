/* exported less */
var less = {
    logLevel: 4,
    errorReporting: 'console'
};