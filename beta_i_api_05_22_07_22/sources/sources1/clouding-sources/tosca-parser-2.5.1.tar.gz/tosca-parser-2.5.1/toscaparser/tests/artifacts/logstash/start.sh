#!/bin/bash
# Run logstash as service in init.d
service logstash stop
service logstash start
