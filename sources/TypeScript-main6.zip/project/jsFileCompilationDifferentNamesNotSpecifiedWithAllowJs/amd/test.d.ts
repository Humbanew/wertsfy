declare var test: number;
declare var test2: number;
