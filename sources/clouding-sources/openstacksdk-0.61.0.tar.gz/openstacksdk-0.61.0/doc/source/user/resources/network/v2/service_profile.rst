openstack.network.v2.service_profile
====================================

.. automodule:: openstack.network.v2.service_profile

The ServiceProfile Class
------------------------

The ``ServiceProfile`` class inherits from
:class:`~openstack.resource.Resource`.

.. autoclass:: openstack.network.v2.service_profile.ServiceProfile
   :members:
