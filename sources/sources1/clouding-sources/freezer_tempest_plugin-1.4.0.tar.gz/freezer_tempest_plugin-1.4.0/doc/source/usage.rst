=====
Usage
=====

To use freezer-tempest-plugin in a project::

    import freezer
