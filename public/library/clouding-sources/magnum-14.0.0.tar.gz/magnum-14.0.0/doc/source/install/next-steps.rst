.. _next-steps:

Next steps
~~~~~~~~~~

Your OpenStack environment now includes the magnum service.

To add more services, see the `additional documentation on installing OpenStack
<https://docs.openstack.org/#install-guides>`_ .
