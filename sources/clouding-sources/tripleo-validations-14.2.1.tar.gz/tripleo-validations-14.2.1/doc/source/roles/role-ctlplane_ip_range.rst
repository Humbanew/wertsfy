=================
ctlplane_ip_range
=================

.. ansibleautoplugin::
   :role: roles/ctlplane_ip_range

