Install base packages required for all overcloud nodes.
