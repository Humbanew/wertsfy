overcloud-secure
================

overcloud-secure is an element to add extra security hardening features to
the tripleo images: unsafe package uninstall.
