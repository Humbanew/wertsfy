.. _glance-api.conf:

---------------
glance-api.conf
---------------

.. show-options::
   :config-file: etc/oslo-config-generator/glance-api.conf
