declare var test: number;
