Install all openstack clients
