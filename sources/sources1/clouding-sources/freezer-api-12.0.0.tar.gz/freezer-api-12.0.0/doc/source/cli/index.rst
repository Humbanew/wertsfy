CLI Reference
=============

.. toctree::
   :maxdepth: 1

   freezer-manager-status
