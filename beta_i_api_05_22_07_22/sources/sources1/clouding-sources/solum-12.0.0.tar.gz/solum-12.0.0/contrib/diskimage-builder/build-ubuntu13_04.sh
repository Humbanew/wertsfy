#!/bin/bash

DIB_RELEASE="raring"
disk-image-create --no-tmpfs -a amd64 vm ubuntu -o u1304-py33.qcow2
