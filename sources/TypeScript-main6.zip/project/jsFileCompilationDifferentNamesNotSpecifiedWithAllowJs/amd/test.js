var test = 10;
var test2 = 10; // Should get compiled
