openstack.accelerator.v2.deployable
============================================

.. automodule:: openstack.accelerator.v2.deployable

The Deployable Class
--------------------

The ``Deployable`` class inherits from :class:`~openstack.resource.Resource`.

.. autoclass:: openstack.accelerator.v2.deployable.Deployable
   :members:

