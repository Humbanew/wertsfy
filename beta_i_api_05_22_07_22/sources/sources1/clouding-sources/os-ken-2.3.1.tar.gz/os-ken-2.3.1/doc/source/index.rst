.. os-ken documentation master file, created by
   sphinx-quickstart on Tue Jul  9 22:26:36 2013.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

======================================
Welcome to the documentation of os_ken
======================================

.. toctree::
   :maxdepth: 2

   readme
   library/index
   contributor/index
   configuration/index
   user/index
   admin/index
   reference/index
   archive

.. only:: html

   .. rubric:: Indices and tables

   * :ref:`genindex`
   * :ref:`modindex`
   * :ref:`search`
