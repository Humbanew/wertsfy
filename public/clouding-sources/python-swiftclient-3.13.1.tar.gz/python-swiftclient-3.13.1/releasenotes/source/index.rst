============================
 Swift Client Release Notes
============================

.. toctree::
   :maxdepth: 1

   current
   xena
   wallaby
   victoria
   ussuri
   train
   stein
   rocky
   queens
   pike
   ocata
   newton
