==========================
Welcome to Heat Dashboard!
==========================

Heat dashboard is a horizon plugin for Heat.

* License: Apache license
* Documentation: https://docs.openstack.org/heat-dashboard/latest/
* Source: https://opendev.org/openstack/heat-dashboard
* Bugs: https://storyboard.openstack.org/#!/project/openstack/heat-dashboard
* Release Notes: https://docs.openstack.org/releasenotes/heat-dashboard

Team and repository tags
------------------------

.. image:: https://governance.openstack.org/tc/badges/heat-dashboard.svg
    :target: https://governance.openstack.org/tc/reference/tags/index.html
