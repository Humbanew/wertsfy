=====================
Programming Reference
=====================

Plugins and EDP
===============

.. toctree::
   :maxdepth: 2

   plugins
   plugin-spi
   edp-spi


REST API
========

.. toctree::
   :maxdepth: 2

   restapi
