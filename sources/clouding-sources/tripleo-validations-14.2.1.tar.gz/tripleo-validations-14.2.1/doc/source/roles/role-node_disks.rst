==========
node_disks
==========

.. ansibleautoplugin::
   :role: roles/node_disks

