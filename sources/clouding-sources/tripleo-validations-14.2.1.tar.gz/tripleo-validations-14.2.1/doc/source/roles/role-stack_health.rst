============
stack_health
============

.. ansibleautoplugin::
   :role: roles/stack_health

