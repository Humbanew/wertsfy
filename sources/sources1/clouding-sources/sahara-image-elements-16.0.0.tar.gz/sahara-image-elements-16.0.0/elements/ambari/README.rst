======
ambari
======

Installs Ambari Management Console

Environment Variables
---------------------

AMBARI_VERSION
  :Required: No
  :Default: 2.4.2.0
  :Description: Version of Ambari Management Console to install
  :Example: ``AMBARI_VERSION="2.2.1.0"`` installs Ambari 2.2.1.0
