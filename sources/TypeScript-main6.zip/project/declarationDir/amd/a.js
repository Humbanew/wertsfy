define(["require", "exports"], function (require, exports) {
    "use strict";
    exports.__esModule = true;
    exports.A = void 0;
    var A = /** @class */ (function () {
        function A() {
        }
        return A;
    }());
    exports.A = A;
});
