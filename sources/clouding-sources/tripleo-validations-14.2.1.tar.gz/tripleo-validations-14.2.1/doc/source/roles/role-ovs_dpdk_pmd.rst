============
ovs_dpdk_pmd
============

.. ansibleautoplugin::
   :role: roles/ovs_dpdk_pmd

