openstack.load_balancer.v2.flavor_profile
=========================================

.. automodule:: openstack.load_balancer.v2.flavor_profile

The FlavorProfile Class
-----------------------

The ``FlavorProfile`` class inherits from
:class:`~openstack.resource.Resource`.

.. autoclass:: openstack.load_balancer.v2.flavor_profile.FlavorProfile
   :members:
