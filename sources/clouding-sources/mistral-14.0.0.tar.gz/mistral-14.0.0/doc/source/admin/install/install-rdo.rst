.. _install-rdo:

Install and configure for Red Hat Enterprise Linux and CentOS
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~


For information on how to install and configure the Workflow service
for Red Hat Enterprise Linux 7 and CentOS 7, refer to the :doc:`Installation
guide for Ubuntu <install-ubuntu>`. Note that some commands vary by distribution
and might differ from the ones described, for instance, package management.
