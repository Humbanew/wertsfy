===================
software deployment
===================


.. autoprogram-cliff:: openstack.orchestration.v1
   :command: software deployment list

.. autoprogram-cliff:: openstack.orchestration.v1
   :command: software deployment create

.. autoprogram-cliff:: openstack.orchestration.v1
   :command: software deployment show

.. autoprogram-cliff:: openstack.orchestration.v1
   :command: software deployment output show

.. autoprogram-cliff:: openstack.orchestration.v1
   :command: software deployment delete

.. autoprogram-cliff:: openstack.orchestration.v1
   :command: software deployment metadata show
