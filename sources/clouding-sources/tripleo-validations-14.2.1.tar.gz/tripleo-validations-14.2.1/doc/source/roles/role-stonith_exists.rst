==============
stonith_exists
==============

.. ansibleautoplugin::
   :role: roles/stonith_exists

