:tocdepth: 2

===================
 Database API
===================

.. rest_expand_all::

.. include:: api-versions.inc
.. include:: datastores.inc
.. include:: datastore-versions.inc
.. include:: instances.inc
.. include:: instance-actions.inc
.. include:: instance-logs.inc
.. include:: backups.inc
.. include:: backup-strategy.inc
.. include:: configurations.inc
.. include:: databases.inc
.. include:: users.inc
.. include:: quotas.inc
