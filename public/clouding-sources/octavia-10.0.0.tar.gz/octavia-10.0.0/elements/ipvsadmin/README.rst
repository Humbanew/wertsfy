Element to install ipvsadmin.


