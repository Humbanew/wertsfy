======================
Zun Command Line Guide
======================

In this section you will find information on Zun’s command line
interface.

.. toctree::
   :maxdepth: 1

   zun-status


.. note::
   Other command line guide for Zun to be added. The work will be
   tracked here: https://blueprints.launchpad.net/zun/+spec/zun-cli-guide
