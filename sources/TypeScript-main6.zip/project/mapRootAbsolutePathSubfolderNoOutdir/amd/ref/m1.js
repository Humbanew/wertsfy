var m1_a1 = 10;
var m1_c1 = /** @class */ (function () {
    function m1_c1() {
    }
    return m1_c1;
}());
var m1_instance1 = new m1_c1();
function m1_f1() {
    return m1_instance1;
}
//# sourceMappingURL=/tests/cases/projects/outputdir_subfolder/mapFiles/ref/m1.js.map