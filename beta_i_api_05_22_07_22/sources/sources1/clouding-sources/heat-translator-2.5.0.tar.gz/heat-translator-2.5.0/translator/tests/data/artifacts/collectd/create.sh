#!/bin/bash
# This script install collectd for monitoring data

apt-get update
apt-get install -y collectd
