local APIData = require(script:WaitForChild("APIData"))
local APILibrarian = require(script:WaitForChild("APILibrarian"))
local APIOperator = require(script:WaitForChild("APIOperator"))

---

local RobloxAPI = {}

function RobloxAPI.new(rawAPIData, enableCache)
    local apiData = APIData.new(rawAPIData)

    local self = {
        Data = apiData,
        Library = APILibrarian.new(apiData, enableCache),
        Operator = APIOperator.new(apiData)
    }
    setmetatable(self, {__index = RobloxAPI})

    return self
end

return RobloxAPI
