---
layout: default
permalink: docs/textmate.html
---

# TextMate Bundle

 Stylus ships with a TextMate bundle, located within `./editors`. To install, simply execute `make install-bundle`, or place `./editors/Stylus.tmbundle` in the appropriate location.
