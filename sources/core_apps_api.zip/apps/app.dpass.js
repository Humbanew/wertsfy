//a Módulo da Humbanew DPass
let dpass = { };