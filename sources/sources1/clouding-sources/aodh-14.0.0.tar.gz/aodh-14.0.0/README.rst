aodh
====

Aodh is the alarming service for OpenStack.

-------------
Documentation
-------------

Documentation for the project can be found at:
  https://docs.openstack.org/aodh/latest/

Release notes can be read online at:
  https://docs.openstack.org/aodh/latest/contributor/releasenotes/index.html


Code Repository
---------------

- Server: https://opendev.org/openstack/aodh/

Bug Tracking
------------

Bugs and feature requests are tracked on Launchpad at:
  https://bugs.launchpad.net/aodh/

IRC
---

IRC Channel: #openstack-telemetry on `OFTC`_.

.. _OFTC: https://oftc.net/
