=============================
undercloud_heat_purge_deleted
=============================

.. ansibleautoplugin::
   :role: roles/undercloud_heat_purge_deleted

