export declare class B {
}
