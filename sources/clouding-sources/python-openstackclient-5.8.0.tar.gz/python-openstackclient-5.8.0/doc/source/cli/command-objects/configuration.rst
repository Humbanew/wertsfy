=============
configuration
=============

Available for all services

.. _configuration-show:

.. autoprogram-cliff:: openstack.common
   :command: configuration show
