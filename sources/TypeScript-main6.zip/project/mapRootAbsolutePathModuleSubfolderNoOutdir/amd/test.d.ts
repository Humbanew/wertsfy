import m1 = require("ref/m1");
export declare var a1: number;
export declare class c1 {
    p1: number;
}
export declare var instance1: c1;
export declare function f1(): c1;
export declare var a2: typeof m1.m1_c1;
