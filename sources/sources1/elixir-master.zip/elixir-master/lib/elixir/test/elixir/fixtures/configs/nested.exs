import Config
config :app, Repo, key: [nested: true]
