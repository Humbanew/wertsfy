=============
Configuration
=============

Tacker-horizon does not need special configuration.

For more configurations, see
`Configuration Guide <https://docs.openstack.org/horizon/latest/configuration/index.html>`_
in the Horizon documentation.
