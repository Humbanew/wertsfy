openstack.load_balancer.v2.availability_zone
============================================

.. automodule:: openstack.load_balancer.v2.availability_zone

The AvailabilityZone Class
--------------------------

The ``AvailabilityZone`` class inherits from
:class:`~openstack.resource.Resource`.

.. autoclass:: openstack.load_balancer.v2.availability_zone.AvailabilityZone
   :members:
