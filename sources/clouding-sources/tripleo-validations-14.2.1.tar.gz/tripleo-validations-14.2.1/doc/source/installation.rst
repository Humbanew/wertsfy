Prerequisites
=============

The TripleO validations requires Ansible ">=2.8,<2.0.0"::

    $ sudo pip install 'ansible>=2.8,<2.10.0'

Installation
============

At the command line::

    $ python3 -m pip install tripleo-validations
