==================
Module - icmp_ping
==================


This module provides for the following ansible plugin:

    * icmp_ping


.. ansibleautoplugin::
   :module: library/icmp_ping.py
   :documentation: true
   :examples: true

