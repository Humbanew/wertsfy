==================
Installation Guide
==================

At the command line::

    $ pip install python-zunclient

Or, if you have virtualenvwrapper installed::

    $ mkvirtualenv python-zunclient
    $ pip install python-zunclient
