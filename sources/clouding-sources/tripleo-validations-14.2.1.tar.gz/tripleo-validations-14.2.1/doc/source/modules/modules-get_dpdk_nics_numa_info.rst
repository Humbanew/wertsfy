================================
Module - get_dpdk_nics_numa_info
================================


This module provides for the following ansible plugin:

    * get_dpdk_nics_numa_info


.. ansibleautoplugin::
   :module: library/get_dpdk_nics_numa_info.py
   :documentation: true
   :examples: true

