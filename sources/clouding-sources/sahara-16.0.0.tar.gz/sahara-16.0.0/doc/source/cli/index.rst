========================
Sahara CLI Documentation
========================

In this section you will find information on Sahara’s command line
interface.

.. toctree::
   :maxdepth: 1

   sahara-status
