============================
So You Want to Contribute...
============================

.. include:: ../../../CONTRIBUTING.rst
