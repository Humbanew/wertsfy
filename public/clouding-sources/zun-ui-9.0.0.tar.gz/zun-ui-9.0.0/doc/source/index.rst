======
Zun UI
======

Horizon plugin for Zun

* Free software: Apache license
* Source: https://opendev.org/openstack/zun-ui
* Bugs: https://bugs.launchpad.net/zun-ui

User Documentation
------------------

.. toctree::
   :maxdepth: 2

   install/index
   configuration/index
   Release Notes <https://docs.openstack.org/releasenotes/zun-ui>

Contributor Guide
-----------------

.. toctree::
   :glob:
   :maxdepth: 2

   contributor/index
