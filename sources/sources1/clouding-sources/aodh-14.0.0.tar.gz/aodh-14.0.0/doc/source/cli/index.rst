======================
Aodh CLI Documentation
======================

In this section you will find information on Aodh’s command line
interface.

.. toctree::
   :maxdepth: 1

   aodh-status
