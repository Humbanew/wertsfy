Building Docs
=============

Developer documentation is generated using Sphinx. To build this documentation,
run the following from the root of the repository::

  $ tox -e docs

The documentation will be built at ``doc/build/``.
