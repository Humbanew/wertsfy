define(["require", "exports"], function (require, exports) {
    "use strict";
    exports.__esModule = true;
    exports.m2_f1 = exports.m2_instance1 = exports.m2_c1 = exports.m2_a1 = void 0;
    exports.m2_a1 = 10;
    var m2_c1 = /** @class */ (function () {
        function m2_c1() {
        }
        return m2_c1;
    }());
    exports.m2_c1 = m2_c1;
    exports.m2_instance1 = new m2_c1();
    function m2_f1() {
        return exports.m2_instance1;
    }
    exports.m2_f1 = m2_f1;
});
//# sourceMappingURL=/tests/cases/projects/outputdir_module_multifolder/mapFiles/outputdir_module_multifolder_ref/m2.js.map