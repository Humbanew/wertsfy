openstack.block_storage.v2.backup
=================================

.. automodule:: openstack.block_storage.v2.backup

The Backup Class
----------------

The ``Backup`` class inherits from :class:`~openstack.resource.Resource`.

.. autoclass:: openstack.block_storage.v2.backup.Backup
   :members:
