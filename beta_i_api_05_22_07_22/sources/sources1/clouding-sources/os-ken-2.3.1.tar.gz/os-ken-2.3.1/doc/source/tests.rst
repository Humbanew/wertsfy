*****
Tests
*****

.. toctree::

   test-vrrp.rst
   test-of-config-with-linc.rst
