Identity v2 Resources
=====================

.. toctree::
   :maxdepth: 1

   v2/extension
   v2/role
   v2/tenant
   v2/user

Identity v3 Resources
=====================

.. toctree::
   :maxdepth: 1

   v3/credential
   v3/domain
   v3/endpoint
   v3/group
   v3/policy
   v3/project
   v3/service
   v3/trust
   v3/user
