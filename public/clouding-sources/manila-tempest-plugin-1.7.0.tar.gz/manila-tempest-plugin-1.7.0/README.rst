=====================
manila-tempest-plugin
=====================

This repository contains a `Tempest`_ `test plugin`_ to verify the
functionality of the `OpenStack Shared File System Service`_, Manila.

See `contributor information`_ to learn more.

* Free software: Apache license
* Documentation: https://docs.openstack.org/manila/latest/
* Release notes: https://docs.openstack.org/releasenotes/manila/
* Source: https://opendev.org/openstack/manila-tempest-plugin
* Bugs: https://bugs.launchpad.net/manila

.. _Tempest: https://docs.openstack.org/tempest
.. _test plugin: https://docs.openstack.org/tempest/latest/plugin.html
.. _contributor information: CONTRIBUTING.rst
.. _OpenStack Shared File System Service: https://docs.openstack.org/manila