==========================
openstack service overview
==========================
The openstack service provides...

The openstack service consists of the following components:

``manila-tempest-plugin-api`` service
  Accepts and responds to end user compute API calls...
