export declare var m2_a1: number;
export declare class m2_c1 {
    m2_c1_p1: number;
}
export declare var m2_instance1: m2_c1;
export declare function m2_f1(): m2_c1;
