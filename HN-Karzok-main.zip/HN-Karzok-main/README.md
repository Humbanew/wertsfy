# HN-Karzok

- A api geradora de arquivos JSON, Markdown, Java e demais scripts de outras linguagens, sistema baseado em PHP.
