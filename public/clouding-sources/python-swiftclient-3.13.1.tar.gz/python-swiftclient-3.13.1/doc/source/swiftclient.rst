.. _swiftclient_package:

swiftclient
==============

.. automodule:: swiftclient

swiftclient.authv1
==================

.. automodule:: swiftclient.authv1
   :inherited-members:

swiftclient.client
==================

.. automodule:: swiftclient.client

swiftclient.service
===================

.. automodule:: swiftclient.service

swiftclient.exceptions
======================

.. automodule:: swiftclient.exceptions

swiftclient.multithreading
==========================

.. automodule:: swiftclient.multithreading

swiftclient.utils
=================

.. automodule:: swiftclient.utils
