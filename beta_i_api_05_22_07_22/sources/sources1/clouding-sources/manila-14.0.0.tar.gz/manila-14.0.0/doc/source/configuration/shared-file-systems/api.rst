=====================================
Shared File Systems API configuration
=====================================

Configuration options
~~~~~~~~~~~~~~~~~~~~~

The following options allow configuration of the APIs that
Shared File Systems service supports.

.. include:: ../tables/manila-api.inc
