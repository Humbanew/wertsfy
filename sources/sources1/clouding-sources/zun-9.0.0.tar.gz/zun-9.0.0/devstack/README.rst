====================
DevStack Integration
====================

This directory contains the files necessary to integrate zun with devstack.

Refer the quickstart guide at
https://docs.openstack.org/zun/latest/contributor/quickstart.html
for more information on using devstack and zun.
