============
Installation
============

At the command line::

    $ pip install ovsdbapp

Or, if you have virtualenvwrapper installed::

    $ mkvirtualenv ovsdbapp
    $ pip install ovsdbapp
