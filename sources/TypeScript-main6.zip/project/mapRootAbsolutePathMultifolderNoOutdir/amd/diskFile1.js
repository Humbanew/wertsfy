var m2_a1 = 10;
var m2_c1 = /** @class */ (function () {
    function m2_c1() {
    }
    return m2_c1;
}());
var m2_instance1 = new m2_c1();
function m2_f1() {
    return m2_instance1;
}
//# sourceMappingURL=/tests/cases/projects/outputdir_multifolder/mapFiles/outputdir_multifolder_ref/m2.js.map