=======================
 Contributor Resources
=======================

For those wishing to develop Trove itself, or to extend Trove's
functionality, the following resources are provided.


.. toctree::
   :maxdepth: 1

   contributing
   design
   functional_test
   testing
