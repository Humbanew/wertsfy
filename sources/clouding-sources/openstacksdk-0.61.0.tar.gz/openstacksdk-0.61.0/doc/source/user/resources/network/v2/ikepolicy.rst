openstack.network.v2.ikepolicy
==============================

.. automodule:: openstack.network.v2.ikepolicy

The IkePolicy Class
-------------------

The ``IkePolicy`` class inherits from
:class:`~openstack.resource.Resource`.

.. autoclass:: openstack.network.v2.ikepolicy.IkePolicy
   :members:
