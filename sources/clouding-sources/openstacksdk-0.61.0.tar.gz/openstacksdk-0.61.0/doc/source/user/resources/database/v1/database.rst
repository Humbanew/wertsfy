openstack.database.v1.database
==============================

.. automodule:: openstack.database.v1.database

The Database Class
------------------

The ``Database`` class inherits from :class:`~openstack.resource.Resource`.

.. autoclass:: openstack.database.v1.database.Database
   :members:
