Element to enable FIPS mode inside the Amphora.

This element configures the Amphora OS to enable FIPS 140-2 mode in the
operating system for the Amphora.

Note: Current this element only supports the Red Hat family of operating
systems.
