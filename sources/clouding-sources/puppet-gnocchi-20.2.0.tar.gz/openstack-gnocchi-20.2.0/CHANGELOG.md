## 8.0.0 and beyond

From 8.0.0 release and beyond, release notes are published on
[docs.openstack.org](https://docs.openstack.org/releasenotes/puppet-gnocchi/).

##2015-11-25 - 7.0.0
###Summary

- Initial release of the puppet-gnocchi module
