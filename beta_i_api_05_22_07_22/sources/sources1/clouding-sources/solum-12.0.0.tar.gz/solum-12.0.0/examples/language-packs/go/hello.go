package main

import "fmt"

func main() {
    fmt.Printf("hello world\n")
}