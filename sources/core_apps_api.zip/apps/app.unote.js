//a Módulo da Humbanew UNote
let unote = { };