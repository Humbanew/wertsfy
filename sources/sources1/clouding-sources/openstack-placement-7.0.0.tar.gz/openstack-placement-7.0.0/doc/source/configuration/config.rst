=====================
Configuration Options
=====================

The following is an overview of all available configuration options in
Placement.  For a sample configuration file, refer to
:doc:`/configuration/sample-config`.

.. show-options::
   :config-file: etc/placement/config-generator.conf
