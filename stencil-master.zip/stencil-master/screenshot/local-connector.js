const { ScreenshotLocalConnector } = require('./index.js');
module.exports = ScreenshotLocalConnector;
