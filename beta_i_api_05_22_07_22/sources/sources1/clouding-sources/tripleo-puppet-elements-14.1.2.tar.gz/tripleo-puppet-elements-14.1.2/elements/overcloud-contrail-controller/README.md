Install all packages required for the overcloud contrail controller role.
