=============
orchestration
=============

.. autoprogram-cliff:: openstack.orchestration.v1
   :command: orchestration template validate

.. autoprogram-cliff:: openstack.orchestration.v1
   :command: orchestration template version list

.. autoprogram-cliff:: openstack.orchestration.v1
   :command: orchestration template function list

.. autoprogram-cliff:: openstack.orchestration.v1
   :command: orchestration resource type list

.. autoprogram-cliff:: openstack.orchestration.v1
   :command: orchestration resource type show

.. autoprogram-cliff:: openstack.orchestration.v1
   :command: orchestration build info

.. autoprogram-cliff:: openstack.orchestration.v1
   :command: orchestration service list
