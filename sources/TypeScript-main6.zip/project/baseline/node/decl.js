"use strict";
exports.__esModule = true;
exports.point = void 0;
;
function point(x, y) {
    return { x: x, y: y };
}
exports.point = point;
