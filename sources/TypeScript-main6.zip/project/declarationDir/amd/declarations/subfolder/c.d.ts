import { A } from '../a';
export declare class C {
    a: A;
}
