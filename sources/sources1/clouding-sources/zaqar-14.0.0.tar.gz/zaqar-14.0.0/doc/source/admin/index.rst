====================
Administration Guide
====================

.. toctree::
   :maxdepth: 2

   subscription_confirm
   OSprofiler
   CORS
   gmr
   running_benchmark
   writing_pipeline_stages
