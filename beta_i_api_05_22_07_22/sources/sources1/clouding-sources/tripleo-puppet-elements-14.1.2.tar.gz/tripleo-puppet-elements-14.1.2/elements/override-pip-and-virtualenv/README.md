This element will override the behavior from the pip-and-virtualenv element
from tripleo-image-elements so that python-pip and python-virtualenv are never
installed.

