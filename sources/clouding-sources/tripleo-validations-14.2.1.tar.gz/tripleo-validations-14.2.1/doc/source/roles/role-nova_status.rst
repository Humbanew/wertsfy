===========
nova_status
===========

.. ansibleautoplugin::
   :role: roles/nova_status

