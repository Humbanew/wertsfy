"use strict";
exports.__esModule = true;
var p = { x: 10, y: 20 };
