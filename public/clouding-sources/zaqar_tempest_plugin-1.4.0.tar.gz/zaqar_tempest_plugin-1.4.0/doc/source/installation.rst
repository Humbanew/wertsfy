============
Installation
============

Tempest automatically discovers installed plugins. That's why you just need
to install the Python packages that contains the Zaqar Tempest plugin in
the same environment where Tempest is installed.

At the command line::

    $ git clone https://git.openstack.org/openstack/zaqar-tempest-plugin
    $ cd zaqar-tempest-plugin/
    $ pip install zaqar-tempest-plugin
