Element to setup an encrypted ramfs to store the TLS certificates and keys.

Enabling this element will mean that the amphora can no longer recover from a
reboot.
