Permit injecting content into /etc/hosts from heat

# Configuration

    hosts: '192.0.2.1 my-host.example.com'
