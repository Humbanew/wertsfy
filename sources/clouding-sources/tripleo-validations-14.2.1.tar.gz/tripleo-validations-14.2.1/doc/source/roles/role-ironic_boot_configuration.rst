=========================
ironic_boot_configuration
=========================

.. ansibleautoplugin::
   :role: roles/ironic_boot_configuration

