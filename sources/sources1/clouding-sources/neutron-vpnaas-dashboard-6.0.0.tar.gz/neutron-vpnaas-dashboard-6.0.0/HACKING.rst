===========================================
Neutron VPNaaS Dashboard Style Commandments
===========================================

Read the OpenStack Style Commandments
https://docs.openstack.org/hacking/latest/user/hacking.html

Project Specific Commandments
-----------------------------

- Read the Horizon contributing documentation at
  https://docs.openstack.org/horizon/latest/contributor/contributing.html
- [M322] Method's default argument shouldn't be mutable.
