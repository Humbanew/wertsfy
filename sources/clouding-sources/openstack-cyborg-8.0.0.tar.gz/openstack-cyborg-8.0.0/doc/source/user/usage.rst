========
Usage
========

To use cyborg in a project::

    import cyborg
