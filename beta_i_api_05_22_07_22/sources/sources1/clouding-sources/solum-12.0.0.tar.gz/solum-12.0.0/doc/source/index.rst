
Welcome to Solum's documentation!
=================================

Contents:

.. toctree::
   :maxdepth: 2

   user/index
   install/index
   configuration/index
   admin/index
   contributor/index
   man/index
   cli/index

.. only:: html

   Indices and tables
   ==================


   * :ref:`genindex`
   * :ref:`search`
